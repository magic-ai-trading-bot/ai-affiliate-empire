-- AI Affiliate Empire Database Backup
-- Environment: development
-- Database: ai_affiliate_empire
-- Host: localhost:5432
-- Timestamp: 2025-10-31 18:03:01 UTC
-- Tables: 19
-- Size: 8740 kB
-- Backup Version: 1.0
--

--
-- PostgreSQL database dump
--

\restrict B2DUDZX2jGc7txCZBcBbdJlekR76p5or7KA4GfgD5axFMwhoNqpIXvl6c9fsO5K

-- Dumped from database version 16.10 (Homebrew)
-- Dumped by pg_dump version 16.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS ai_affiliate_empire;
--
-- Name: ai_affiliate_empire; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE ai_affiliate_empire WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


\unrestrict B2DUDZX2jGc7txCZBcBbdJlekR76p5or7KA4GfgD5axFMwhoNqpIXvl6c9fsO5K
\connect ai_affiliate_empire
\restrict B2DUDZX2jGc7txCZBcBbdJlekR76p5or7KA4GfgD5axFMwhoNqpIXvl6c9fsO5K

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AlertLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AlertLevel" AS ENUM (
    'WARNING',
    'CRITICAL',
    'EMERGENCY'
);


--
-- Name: ApiKeyStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ApiKeyStatus" AS ENUM (
    'ACTIVE',
    'REVOKED',
    'EXPIRED'
);


--
-- Name: BlogStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BlogStatus" AS ENUM (
    'DRAFT',
    'PUBLISHED',
    'ARCHIVED'
);


--
-- Name: CostService; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CostService" AS ENUM (
    'OPENAI',
    'CLAUDE',
    'ELEVENLABS',
    'PIKA',
    'DALLE',
    'S3',
    'DATABASE',
    'COMPUTE',
    'OTHER'
);


--
-- Name: NetworkStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NetworkStatus" AS ENUM (
    'ACTIVE',
    'PAUSED',
    'DISABLED'
);


--
-- Name: OptimizationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OptimizationStatus" AS ENUM (
    'PENDING',
    'APPLIED',
    'REJECTED',
    'EXPIRED'
);


--
-- Name: OptimizationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OptimizationType" AS ENUM (
    'MODEL_SELECTION',
    'BATCH_PROCESSING',
    'CACHE_OPTIMIZATION',
    'RATE_LIMITING',
    'RESOURCE_CLEANUP',
    'PROVIDER_SWITCH'
);


--
-- Name: Platform; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Platform" AS ENUM (
    'YOUTUBE',
    'TIKTOK',
    'INSTAGRAM',
    'FACEBOOK',
    'BLOG'
);


--
-- Name: Priority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Priority" AS ENUM (
    'HIGH',
    'MEDIUM',
    'LOW'
);


--
-- Name: ProductStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProductStatus" AS ENUM (
    'ACTIVE',
    'PAUSED',
    'ARCHIVED',
    'OUT_OF_STOCK'
);


--
-- Name: PublicationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PublicationStatus" AS ENUM (
    'PENDING',
    'SCHEDULED',
    'PUBLISHING',
    'PUBLISHED',
    'FAILED'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'USER',
    'READONLY'
);


--
-- Name: UserStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserStatus" AS ENUM (
    'ACTIVE',
    'SUSPENDED',
    'INACTIVE'
);


--
-- Name: VideoStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."VideoStatus" AS ENUM (
    'PENDING',
    'GENERATING',
    'READY',
    'FAILED',
    'ARCHIVED'
);


--
-- Name: WorkflowStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkflowStatus" AS ENUM (
    'RUNNING',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AffiliateNetwork; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AffiliateNetwork" (
    id text NOT NULL,
    name text NOT NULL,
    "apiUrl" text,
    "apiKey" text,
    "secretKey" text,
    "commissionRate" numeric(5,2) DEFAULT 0 NOT NULL,
    status public."NetworkStatus" DEFAULT 'ACTIVE'::public."NetworkStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ApiKey; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ApiKey" (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    "keyHash" text NOT NULL,
    "keyPrefix" text NOT NULL,
    permissions text[],
    "lastUsedAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone,
    status public."ApiKeyStatus" DEFAULT 'ACTIVE'::public."ApiKeyStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    resource text,
    method text,
    "ipAddress" text,
    "userAgent" text,
    status text NOT NULL,
    "errorMessage" text,
    metadata text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Blog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Blog" (
    id text NOT NULL,
    "productId" text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text NOT NULL,
    excerpt text,
    "metaTitle" text,
    "metaDescription" text,
    keywords text,
    language text DEFAULT 'en'::text NOT NULL,
    status public."BlogStatus" DEFAULT 'DRAFT'::public."BlogStatus" NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: BudgetAlert; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BudgetAlert" (
    id text NOT NULL,
    level public."AlertLevel" NOT NULL,
    threshold integer NOT NULL,
    "currentSpend" numeric(10,2) NOT NULL,
    "budgetLimit" numeric(10,2) NOT NULL,
    "percentUsed" integer NOT NULL,
    message text NOT NULL,
    "actionsTaken" jsonb,
    "emailSent" boolean DEFAULT false NOT NULL,
    "slackSent" boolean DEFAULT false NOT NULL,
    "notificationError" text,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: BudgetConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BudgetConfig" (
    id text NOT NULL,
    "monthlyLimit" numeric(10,2) NOT NULL,
    "dailyLimit" numeric(10,2) NOT NULL,
    "warningThreshold" integer DEFAULT 80 NOT NULL,
    "criticalThreshold" integer DEFAULT 100 NOT NULL,
    "emergencyThreshold" integer DEFAULT 150 NOT NULL,
    "emailAlerts" boolean DEFAULT true NOT NULL,
    "slackAlerts" boolean DEFAULT false NOT NULL,
    "emailRecipients" text[],
    "slackWebhookUrl" text,
    "autoScaleDown" boolean DEFAULT true NOT NULL,
    "emergencyStop" boolean DEFAULT true NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CostEntry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CostEntry" (
    id text NOT NULL,
    service public."CostService" NOT NULL,
    operation text NOT NULL,
    amount numeric(10,4) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    tokens integer,
    "inputTokens" integer,
    "outputTokens" integer,
    duration integer,
    "storageBytes" bigint,
    "computeMinutes" integer,
    "resourceId" text,
    "resourceType" text,
    metadata jsonb,
    provider text NOT NULL,
    model text,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: CostOptimization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CostOptimization" (
    id text NOT NULL,
    type public."OptimizationType" NOT NULL,
    priority public."Priority" NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "currentCost" numeric(10,2) NOT NULL,
    "estimatedSavings" numeric(10,2) NOT NULL,
    "savingsPercent" integer NOT NULL,
    recommendation text NOT NULL,
    implementation text,
    status public."OptimizationStatus" NOT NULL,
    "appliedAt" timestamp(3) without time zone,
    "appliedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: DailyCostSummary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DailyCostSummary" (
    id text NOT NULL,
    date date NOT NULL,
    "openaiCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "claudeCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "elevenlabsCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "pikaCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "dalleCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "storageCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "databaseCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "computeCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "otherCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalCost" numeric(10,2) DEFAULT 0 NOT NULL,
    "totalTokens" integer DEFAULT 0 NOT NULL,
    "totalDuration" integer DEFAULT 0 NOT NULL,
    "totalStorage" bigint DEFAULT 0 NOT NULL,
    "totalCompute" integer DEFAULT 0 NOT NULL,
    "videosGenerated" integer DEFAULT 0 NOT NULL,
    "blogsGenerated" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: NetworkAnalytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NetworkAnalytics" (
    id text NOT NULL,
    "networkId" text NOT NULL,
    date date NOT NULL,
    "totalClicks" integer DEFAULT 0 NOT NULL,
    "totalConversions" integer DEFAULT 0 NOT NULL,
    "totalRevenue" numeric(10,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: PlatformAnalytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PlatformAnalytics" (
    id text NOT NULL,
    "publicationId" text NOT NULL,
    date date NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    likes integer DEFAULT 0 NOT NULL,
    comments integer DEFAULT 0 NOT NULL,
    shares integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    "watchTime" integer DEFAULT 0 NOT NULL,
    engagement double precision DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    asin text,
    "externalId" text,
    title text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    commission numeric(5,2) NOT NULL,
    "commissionType" text DEFAULT 'percentage'::text NOT NULL,
    "affiliateUrl" text NOT NULL,
    "imageUrl" text,
    category text,
    brand text,
    "networkId" text NOT NULL,
    "trendScore" double precision DEFAULT 0 NOT NULL,
    "profitScore" double precision DEFAULT 0 NOT NULL,
    "viralityScore" double precision DEFAULT 0 NOT NULL,
    "overallScore" double precision DEFAULT 0 NOT NULL,
    status public."ProductStatus" DEFAULT 'ACTIVE'::public."ProductStatus" NOT NULL,
    "lastRankedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ProductAnalytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductAnalytics" (
    id text NOT NULL,
    "productId" text NOT NULL,
    date date NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    conversions integer DEFAULT 0 NOT NULL,
    revenue numeric(10,2) DEFAULT 0 NOT NULL,
    ctr double precision DEFAULT 0 NOT NULL,
    "conversionRate" double precision DEFAULT 0 NOT NULL,
    roi double precision DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Publication; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Publication" (
    id text NOT NULL,
    "videoId" text NOT NULL,
    platform public."Platform" NOT NULL,
    "platformPostId" text,
    url text,
    title text,
    caption text,
    hashtags text,
    status public."PublicationStatus" DEFAULT 'PENDING'::public."PublicationStatus" NOT NULL,
    "publishedAt" timestamp(3) without time zone,
    "errorMessage" text,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: SystemConfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SystemConfig" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    username text NOT NULL,
    "passwordHash" text NOT NULL,
    "firstName" text,
    "lastName" text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    status public."UserStatus" DEFAULT 'ACTIVE'::public."UserStatus" NOT NULL,
    "refreshToken" text,
    "resetToken" text,
    "resetTokenExpiry" timestamp(3) without time zone,
    "lastLoginAt" timestamp(3) without time zone,
    "emailVerifiedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Video; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Video" (
    id text NOT NULL,
    "productId" text NOT NULL,
    title text NOT NULL,
    description text,
    script text NOT NULL,
    duration integer NOT NULL,
    "videoUrl" text,
    "thumbnailUrl" text,
    "voiceUrl" text,
    "voiceProvider" text,
    "videoProvider" text DEFAULT 'pikalabs'::text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    status public."VideoStatus" DEFAULT 'PENDING'::public."VideoStatus" NOT NULL,
    "generatedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: WorkflowLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WorkflowLog" (
    id text NOT NULL,
    "workflowId" text NOT NULL,
    "workflowType" text NOT NULL,
    status public."WorkflowStatus" NOT NULL,
    "startedAt" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone,
    duration integer,
    result text,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AffiliateNetwork; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AffiliateNetwork" (id, name, "apiUrl", "apiKey", "secretKey", "commissionRate", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ApiKey; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ApiKey" (id, "userId", name, "keyHash", "keyPrefix", permissions, "lastUsedAt", "expiresAt", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "userId", action, resource, method, "ipAddress", "userAgent", status, "errorMessage", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: Blog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Blog" (id, "productId", title, slug, content, excerpt, "metaTitle", "metaDescription", keywords, language, status, "publishedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: BudgetAlert; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BudgetAlert" (id, level, threshold, "currentSpend", "budgetLimit", "percentUsed", message, "actionsTaken", "emailSent", "slackSent", "notificationError", "periodStart", "periodEnd", "createdAt") FROM stdin;
\.


--
-- Data for Name: BudgetConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BudgetConfig" (id, "monthlyLimit", "dailyLimit", "warningThreshold", "criticalThreshold", "emergencyThreshold", "emailAlerts", "slackAlerts", "emailRecipients", "slackWebhookUrl", "autoScaleDown", "emergencyStop", "periodStart", "periodEnd", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CostEntry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CostEntry" (id, service, operation, amount, currency, tokens, "inputTokens", "outputTokens", duration, "storageBytes", "computeMinutes", "resourceId", "resourceType", metadata, provider, model, "timestamp", "createdAt") FROM stdin;
\.


--
-- Data for Name: CostOptimization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CostOptimization" (id, type, priority, title, description, "currentCost", "estimatedSavings", "savingsPercent", recommendation, implementation, status, "appliedAt", "appliedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: DailyCostSummary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DailyCostSummary" (id, date, "openaiCost", "claudeCost", "elevenlabsCost", "pikaCost", "dalleCost", "storageCost", "databaseCost", "computeCost", "otherCost", "totalCost", "totalTokens", "totalDuration", "totalStorage", "totalCompute", "videosGenerated", "blogsGenerated", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: NetworkAnalytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."NetworkAnalytics" (id, "networkId", date, "totalClicks", "totalConversions", "totalRevenue", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PlatformAnalytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PlatformAnalytics" (id, "publicationId", date, views, likes, comments, shares, clicks, "watchTime", engagement, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Product" (id, asin, "externalId", title, description, price, currency, commission, "commissionType", "affiliateUrl", "imageUrl", category, brand, "networkId", "trendScore", "profitScore", "viralityScore", "overallScore", status, "lastRankedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProductAnalytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductAnalytics" (id, "productId", date, views, clicks, conversions, revenue, ctr, "conversionRate", roi, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Publication; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Publication" (id, "videoId", platform, "platformPostId", url, title, caption, hashtags, status, "publishedAt", "errorMessage", "retryCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SystemConfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SystemConfig" (id, key, value, description, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, username, "passwordHash", "firstName", "lastName", role, status, "refreshToken", "resetToken", "resetTokenExpiry", "lastLoginAt", "emailVerifiedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Video; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Video" (id, "productId", title, description, script, duration, "videoUrl", "thumbnailUrl", "voiceUrl", "voiceProvider", "videoProvider", language, status, "generatedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: WorkflowLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WorkflowLog" (id, "workflowId", "workflowType", status, "startedAt", "completedAt", duration, result, "errorMessage", "createdAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
88b940de-5560-4745-865c-43c84da3451c	532958693e5e04c52684f67c766fcced4b9a94971f4beae625841eb49645eae6	2025-10-31 13:53:13.569773+07	20251031065313_add_cost_tracking_auth_gdpr_models	\N	\N	2025-10-31 13:53:13.533719+07	1
\.


--
-- Name: AffiliateNetwork AffiliateNetwork_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AffiliateNetwork"
    ADD CONSTRAINT "AffiliateNetwork_pkey" PRIMARY KEY (id);


--
-- Name: ApiKey ApiKey_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Blog Blog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Blog"
    ADD CONSTRAINT "Blog_pkey" PRIMARY KEY (id);


--
-- Name: BudgetAlert BudgetAlert_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BudgetAlert"
    ADD CONSTRAINT "BudgetAlert_pkey" PRIMARY KEY (id);


--
-- Name: BudgetConfig BudgetConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BudgetConfig"
    ADD CONSTRAINT "BudgetConfig_pkey" PRIMARY KEY (id);


--
-- Name: CostEntry CostEntry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CostEntry"
    ADD CONSTRAINT "CostEntry_pkey" PRIMARY KEY (id);


--
-- Name: CostOptimization CostOptimization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CostOptimization"
    ADD CONSTRAINT "CostOptimization_pkey" PRIMARY KEY (id);


--
-- Name: DailyCostSummary DailyCostSummary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DailyCostSummary"
    ADD CONSTRAINT "DailyCostSummary_pkey" PRIMARY KEY (id);


--
-- Name: NetworkAnalytics NetworkAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NetworkAnalytics"
    ADD CONSTRAINT "NetworkAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: PlatformAnalytics PlatformAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PlatformAnalytics"
    ADD CONSTRAINT "PlatformAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: ProductAnalytics ProductAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductAnalytics"
    ADD CONSTRAINT "ProductAnalytics_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: Publication Publication_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Publication"
    ADD CONSTRAINT "Publication_pkey" PRIMARY KEY (id);


--
-- Name: SystemConfig SystemConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemConfig"
    ADD CONSTRAINT "SystemConfig_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Video Video_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Video"
    ADD CONSTRAINT "Video_pkey" PRIMARY KEY (id);


--
-- Name: WorkflowLog WorkflowLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WorkflowLog"
    ADD CONSTRAINT "WorkflowLog_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AffiliateNetwork_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "AffiliateNetwork_name_key" ON public."AffiliateNetwork" USING btree (name);


--
-- Name: AffiliateNetwork_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AffiliateNetwork_status_idx" ON public."AffiliateNetwork" USING btree (status);


--
-- Name: ApiKey_keyHash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ApiKey_keyHash_idx" ON public."ApiKey" USING btree ("keyHash");


--
-- Name: ApiKey_keyHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ApiKey_keyHash_key" ON public."ApiKey" USING btree ("keyHash");


--
-- Name: ApiKey_status_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ApiKey_status_expiresAt_idx" ON public."ApiKey" USING btree (status, "expiresAt");


--
-- Name: ApiKey_userId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ApiKey_userId_status_idx" ON public."ApiKey" USING btree ("userId", status);


--
-- Name: AuditLog_action_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_action_createdAt_idx" ON public."AuditLog" USING btree (action, "createdAt");


--
-- Name: AuditLog_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_status_createdAt_idx" ON public."AuditLog" USING btree (status, "createdAt");


--
-- Name: AuditLog_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_userId_createdAt_idx" ON public."AuditLog" USING btree ("userId", "createdAt");


--
-- Name: Blog_productId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Blog_productId_status_idx" ON public."Blog" USING btree ("productId", status);


--
-- Name: Blog_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Blog_slug_key" ON public."Blog" USING btree (slug);


--
-- Name: Blog_status_publishedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Blog_status_publishedAt_idx" ON public."Blog" USING btree (status, "publishedAt");


--
-- Name: BudgetAlert_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BudgetAlert_createdAt_idx" ON public."BudgetAlert" USING btree ("createdAt");


--
-- Name: BudgetAlert_level_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BudgetAlert_level_createdAt_idx" ON public."BudgetAlert" USING btree (level, "createdAt");


--
-- Name: BudgetConfig_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "BudgetConfig_isActive_idx" ON public."BudgetConfig" USING btree ("isActive");


--
-- Name: CostEntry_provider_model_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CostEntry_provider_model_idx" ON public."CostEntry" USING btree (provider, model);


--
-- Name: CostEntry_resourceId_resourceType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CostEntry_resourceId_resourceType_idx" ON public."CostEntry" USING btree ("resourceId", "resourceType");


--
-- Name: CostEntry_service_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CostEntry_service_timestamp_idx" ON public."CostEntry" USING btree (service, "timestamp");


--
-- Name: CostEntry_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CostEntry_timestamp_idx" ON public."CostEntry" USING btree ("timestamp");


--
-- Name: CostOptimization_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CostOptimization_createdAt_idx" ON public."CostOptimization" USING btree ("createdAt");


--
-- Name: CostOptimization_status_priority_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CostOptimization_status_priority_idx" ON public."CostOptimization" USING btree (status, priority);


--
-- Name: DailyCostSummary_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DailyCostSummary_date_idx" ON public."DailyCostSummary" USING btree (date);


--
-- Name: DailyCostSummary_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DailyCostSummary_date_key" ON public."DailyCostSummary" USING btree (date);


--
-- Name: NetworkAnalytics_networkId_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "NetworkAnalytics_networkId_date_idx" ON public."NetworkAnalytics" USING btree ("networkId", date);


--
-- Name: NetworkAnalytics_networkId_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "NetworkAnalytics_networkId_date_key" ON public."NetworkAnalytics" USING btree ("networkId", date);


--
-- Name: PlatformAnalytics_publicationId_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PlatformAnalytics_publicationId_date_idx" ON public."PlatformAnalytics" USING btree ("publicationId", date);


--
-- Name: PlatformAnalytics_publicationId_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PlatformAnalytics_publicationId_date_key" ON public."PlatformAnalytics" USING btree ("publicationId", date);


--
-- Name: ProductAnalytics_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductAnalytics_date_idx" ON public."ProductAnalytics" USING btree (date);


--
-- Name: ProductAnalytics_productId_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductAnalytics_productId_date_idx" ON public."ProductAnalytics" USING btree ("productId", date);


--
-- Name: ProductAnalytics_productId_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ProductAnalytics_productId_date_key" ON public."ProductAnalytics" USING btree ("productId", date);


--
-- Name: Product_asin_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_asin_key" ON public."Product" USING btree (asin);


--
-- Name: Product_category_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_category_status_idx" ON public."Product" USING btree (category, status);


--
-- Name: Product_networkId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_networkId_status_idx" ON public."Product" USING btree ("networkId", status);


--
-- Name: Product_status_overallScore_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_status_overallScore_idx" ON public."Product" USING btree (status, "overallScore");


--
-- Name: Publication_platform_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Publication_platform_status_idx" ON public."Publication" USING btree (platform, status);


--
-- Name: Publication_publishedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Publication_publishedAt_idx" ON public."Publication" USING btree ("publishedAt");


--
-- Name: Publication_videoId_platform_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Publication_videoId_platform_idx" ON public."Publication" USING btree ("videoId", platform);


--
-- Name: SystemConfig_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SystemConfig_key_key" ON public."SystemConfig" USING btree (key);


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_status_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_status_role_idx" ON public."User" USING btree (status, role);


--
-- Name: User_username_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_username_idx" ON public."User" USING btree (username);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: Video_productId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Video_productId_status_idx" ON public."Video" USING btree ("productId", status);


--
-- Name: Video_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Video_status_createdAt_idx" ON public."Video" USING btree (status, "createdAt");


--
-- Name: WorkflowLog_status_startedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WorkflowLog_status_startedAt_idx" ON public."WorkflowLog" USING btree (status, "startedAt");


--
-- Name: WorkflowLog_workflowType_startedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WorkflowLog_workflowType_startedAt_idx" ON public."WorkflowLog" USING btree ("workflowType", "startedAt");


--
-- Name: ApiKey ApiKey_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ApiKey"
    ADD CONSTRAINT "ApiKey_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Blog Blog_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Blog"
    ADD CONSTRAINT "Blog_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: NetworkAnalytics NetworkAnalytics_networkId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NetworkAnalytics"
    ADD CONSTRAINT "NetworkAnalytics_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES public."AffiliateNetwork"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PlatformAnalytics PlatformAnalytics_publicationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PlatformAnalytics"
    ADD CONSTRAINT "PlatformAnalytics_publicationId_fkey" FOREIGN KEY ("publicationId") REFERENCES public."Publication"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProductAnalytics ProductAnalytics_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductAnalytics"
    ADD CONSTRAINT "ProductAnalytics_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Product Product_networkId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_networkId_fkey" FOREIGN KEY ("networkId") REFERENCES public."AffiliateNetwork"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Publication Publication_videoId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Publication"
    ADD CONSTRAINT "Publication_videoId_fkey" FOREIGN KEY ("videoId") REFERENCES public."Video"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Video Video_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Video"
    ADD CONSTRAINT "Video_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict B2DUDZX2jGc7txCZBcBbdJlekR76p5or7KA4GfgD5axFMwhoNqpIXvl6c9fsO5K

